package application;

public class InvalidSequenceException extends Exception {
public InvalidSequenceException(String string) {
		super(string);
	}


}
