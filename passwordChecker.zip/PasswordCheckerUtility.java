package application;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class PasswordCheckerUtility {
	
public PasswordCheckerUtility() {
	
}
	
public static boolean isValidPassword(String pass) throws LengthException,
															NoUpperAlphaException,
															NoLowerAlphaException,
															NoDigitException,
															NoSpecialCharacterException,
															InvalidSequenceException {
	/*
	 * LengthException - thrown if length is less than 6 characters
	 * NoUpperAlphaException - thrown if no uppercase alphabetic
	 * NoLowerAlphaException - thrown if no lowercase alphabetic NoDigitException -
	 * thrown if no digit NoSpecialCharacterException - thrown if does not meet
	 * SpecialCharacter requirement InvalidSequenceException - thrown if more than 2
	 * of same character.
	 */
																						
	if(!(isValidLength(pass))) {
			  
		  throw new LengthException("The password must be at least 6 characters long");
	}
	if(!(hasUpperAlpha(pass))) {
		throw new NoUpperAlphaException("The password must contain at least one upper case alphabetic character");
	}
		if(!(hasLowerAlpha(pass))) {
			throw new NoLowerAlphaException("The password must contain at least one lower case alphabetic character");
		}
	 if(!(hasDigit(pass))) {
			throw new NoDigitException("The password must be at least 6 characters long");
	 }
	if(!(hasSpecialChar(pass))) {
		throw new NoSpecialCharacterException("The password must contain at least one special character");
	}
	if(hasSameCharInSequence(pass)) {
		throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");	
		}
	return true;
}
public static boolean isWeakPassword(String pass) throws WeakPasswordException {
	
		
			if(hasBetweenSixAndNineChars(pass)) {
				throw new WeakPasswordException("The password is OK but weak");	
			}
			
   return false;
		
		
}

public static boolean hasBetweenSixAndNineChars(String between6And9Chars)  {
	
		if(between6And9Chars.length() >= 6 && between6And9Chars.length() <= 9) {
			return true;
	}
	return false;
}


public static boolean hasSpecialChar(String withNoDuplicate) throws NoSpecialCharacterException {
	
	Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
	Matcher matcher = pattern.matcher(withNoDuplicate);
	if (!matcher.matches()) {
		return true;
	}
	throw new NoSpecialCharacterException("The password must contain at least one special character");
	
}


public static boolean hasSameCharInSequence(String string) throws InvalidSequenceException {
	
	int count = 0;
	
	
	for( int x = 0; x < string.length(); x++) {
		for( int y = 0; y < string.length(); y++) {
			if(string.charAt(x) ==  string.charAt(y)) {
				count++;	
				
		}	
		}
		if(count++ > 2) {
			throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");
		}
		count = 0;
		
	}

	
	
	return false;
	
}


public static boolean hasDigit(String password) throws NoDigitException {
	
	for( int x = 0; x < password.length(); x++) {
		if(Character.isDigit(password.charAt(x))) {
			return true;
		}
	}
	throw new NoDigitException("The password must contain at least one digit");
}


public static boolean hasLowerAlpha(String allCaps) throws NoLowerAlphaException {
	
	for( int x = 0; x < allCaps.length(); x++) {
		if(Character.isLowerCase(allCaps.charAt(x))) {
			return true;
		}
	}
	
	
	throw new NoLowerAlphaException("The password must contain at least one lower case alphabetic character");
	
}


public static boolean hasUpperAlpha(String passwordConfirm) throws NoUpperAlphaException   {

	for( int x = 0; x < passwordConfirm.length(); x++) {
		if(Character.isUpperCase(passwordConfirm.charAt(x))) {
			return true;
		}
	}
	
	throw new NoUpperAlphaException("The password must contain at least one upper case alphabetic character");
}


public static boolean isValidLength(String password) throws LengthException  {
	 
		if(!(password.length() >= 6)) { 
			throw new LengthException("The password must be at least 6 characters long");
		}
	
	
	  return true;
}
public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwordsArray) {
	
				ArrayList<String> newConverted = new ArrayList<String>();
				for(String conv: passwordsArray) {
				try {
				   isValidPassword(conv);
				}
				catch(LengthException|
						  NoUpperAlphaException| NoLowerAlphaException| NoDigitException|
						  InvalidSequenceException|NoSpecialCharacterException e) {
				
					newConverted.add(conv+" -> "+ e.getMessage());
		
				}
				}
				
				
	
	return newConverted;
}



public static void comparePasswords (String password, String passwordConfirm) throws UnmatchedException {

		
	if(!(password.equals(passwordConfirm))) {
			
		throw new UnmatchedException();
	}
	
	
	
}

public static boolean comparePasswordsWithReturn(String passwordString, String passwordAString) {
	if( passwordString.equals(passwordAString)) {
		return true;
	}
	return false;
}

}
