package application;

public class NoSpecialCharacterException extends Exception{

	public NoSpecialCharacterException(String string) {
		super(string);
	}
 
	
}
