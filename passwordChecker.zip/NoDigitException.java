package application;

public class NoDigitException extends Exception {
public NoDigitException(String string) {
		super(string);
	}


}
