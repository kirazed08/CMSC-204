package application;

public class NoUpperAlphaException extends Exception {
 public NoUpperAlphaException(String string) {
		super(string);
	}


}
