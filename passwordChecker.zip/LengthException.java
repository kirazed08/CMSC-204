package application;

public class LengthException extends Exception {
	public LengthException(String string) {
		super(string);
	}

}
