package application;

public class NoLowerAlphaException extends Exception {
 public NoLowerAlphaException(String string) {
		super(string);
	}


}
